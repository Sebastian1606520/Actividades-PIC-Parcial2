import { LitElement, html } from 'lit-element';
class button extends LitElement {
    render(){
        return html`
            <button>Aceptar</button>
        
        `;
    }
}

window.customElements.define("wc-button", button);